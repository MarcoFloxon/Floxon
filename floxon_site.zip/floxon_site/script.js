(function(){const userLang=navigator.language.startsWith('de')?'de':'en';document.documentElement.lang=userLang})();function switchLang(lang){document.documentElement.lang=lang;}
